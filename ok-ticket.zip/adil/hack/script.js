document.addEventListener('DOMContentLoaded', () => {
    // --- Mock Data ---
    let users = [
        { username: 'admin', password: 'password', role: 'Admin' },
        { username: 'agent', password: 'password', role: 'SupportAgent' },
        { username: 'user', password: 'password', role: 'EndUser' }
    ];
    let tickets = [
        { id: 1, subject: 'Website is down', description: 'The main website is not accessible.', category: 'Technical', status: 'Open', createdBy: 'user', replies: 2, lastModified: new Date() },
        { id: 2, subject: 'Billing issue', description: 'I have a question about my recent invoice.', category: 'Billing', status: 'In Progress', createdBy: 'user', replies: 5, lastModified: new Date() }
    ];
    let categories = ['Technical', 'Billing', 'General Inquiry'];
    let currentUser = null;

    // --- DOM Elements ---
    const authContainer = document.getElementById('auth-container');
    const appContainer = document.getElementById('app-container');
    const loginForm = document.getElementById('login-form');
    const registerForm = document.getElementById('register-form');
    const showRegister = document.getElementById('show-register');
    const showLogin = document.getElementById('show-login');
    const loginBtn = document.getElementById('login-btn');
    const registerBtn = document.getElementById('register-btn');
    const logoutBtn = document.getElementById('logout-btn');
    const welcomeMsg = document.getElementById('welcome-msg');
    const createTicketBtn = document.getElementById('create-ticket-btn');
    const ticketModal = document.getElementById('ticket-modal');
    const closeModal = document.querySelector('.close-btn');
    const ticketForm = document.getElementById('ticket-form');
    const ticketsContainer = document.getElementById('tickets-container');
    const adminPanel = document.getElementById('admin-panel');
    const addCategoryBtn = document.getElementById('add-category-btn');
    const searchInput = document.getElementById('search-input');
    const filterStatus = document.getElementById('filter-status');
    const sortTickets = document.getElementById('sort-tickets');
    
    // --- Event Listeners ---
    showRegister.addEventListener('click', () => {
        loginForm.style.display = 'none';
        registerForm.style.display = 'block';
    });

    showLogin.addEventListener('click', () => {
        registerForm.style.display = 'none';
        loginForm.style.display = 'block';
    });

    loginBtn.addEventListener('click', handleLogin);
    registerBtn.addEventListener('click', handleRegister);
    logoutBtn.addEventListener('click', handleLogout);
    createTicketBtn.addEventListener('click', () => ticketModal.style.display = 'block');
    closeModal.addEventListener('click', () => ticketModal.style.display = 'none');
    ticketForm.addEventListener('submit', handleTicketSubmit);
    addCategoryBtn.addEventListener('click', handleAddCategory);
    searchInput.addEventListener('input', renderTickets);
    filterStatus.addEventListener('change', renderTickets);
    sortTickets.addEventListener('change', renderTickets);

    // --- Functions ---
    function handleLogin() {
        const username = document.getElementById('login-username').value;
        const password = document.getElementById('login-password').value;
        const user = users.find(u => u.username === username && u.password === password);

        if (user) {
            currentUser = user;
            authContainer.style.display = 'none';
            appContainer.style.display = 'block';
            welcomeMsg.textContent = `Welcome, ${currentUser.username} (${currentUser.role})`;
            setupUIForRole();
            renderTickets();
        } else {
            alert('Invalid credentials');
        }
    }

    function handleRegister() {
        const username = document.getElementById('register-username').value;
        const password = document.getElementById('register-password').value;
        const role = document.getElementById('register-role').value;

        if (users.find(u => u.username === username)) {
            alert('Username already exists');
        } else {
            users.push({ username, password, role });
            alert('Registration successful! Please login.');
            showLogin.click();
        }
    }

    function handleLogout() {
        currentUser = null;
        authContainer.style.display = 'block';
        appContainer.style.display = 'none';
    }

    function setupUIForRole() {
        if (currentUser.role === 'Admin') {
            adminPanel.style.display = 'block';
        } else {
            adminPanel.style.display = 'none';
        }
        updateCategoryOptions();
    }

    function renderTickets() {
        let filteredTickets = tickets;

        if (currentUser.role === 'EndUser') {
            filteredTickets = filteredTickets.filter(t => t.createdBy === currentUser.username);
        }

        const searchTerm = searchInput.value.toLowerCase();
        if (searchTerm) {
            filteredTickets = filteredTickets.filter(t => t.category.toLowerCase().includes(searchTerm));
        }

        const statusFilter = filterStatus.value;
        if (statusFilter !== 'All') {
            filteredTickets = filteredTickets.filter(t => t.status === statusFilter);
        }

        const sortOption = sortTickets.value;
        if (sortOption === 'replies') {
            filteredTickets.sort((a, b) => b.replies - a.replies);
        } else {
            filteredTickets.sort((a, b) => b.lastModified - a.lastModified);
        }

        ticketsContainer.innerHTML = '';
        filteredTickets.forEach(ticket => {
            const ticketEl = document.createElement('div');
            ticketEl.classList.add('ticket');
            ticketEl.innerHTML = `
                <div class="ticket-header">
                    <span>${ticket.subject}</span>
                    <span>${ticket.status}</span>
                </div>
                <div class="ticket-body">${ticket.description}</div>
                <div class="ticket-footer">
                    <span>Category: ${ticket.category}</span>
                    <span>By: ${ticket.createdBy}</span>
                </div>
            `;
            ticketsContainer.appendChild(ticketEl);
        });
    }

    function handleTicketSubmit(e) {
        e.preventDefault();
        const newTicket = {
            id: tickets.length + 1,
            subject: document.getElementById('ticket-subject').value,
            description: document.getElementById('ticket-description').value,
            category: document.getElementById('ticket-category').value,
            status: 'Open',
            createdBy: currentUser.username,
            replies: 0,
            lastModified: new Date()
        };
        tickets.push(newTicket);
        ticketModal.style.display = 'none';
        ticketForm.reset();
        renderTickets();
    }
    
    function handleAddCategory() {
        const newCategoryInput = document.getElementById('new-category-input');
        const newCategory = newCategoryInput.value.trim();
        if (newCategory && !categories.includes(newCategory)) {
            categories.push(newCategory);
            newCategoryInput.value = '';
            updateCategoryOptions();
            alert(`Category '${newCategory}' added.`);
        } else {
            alert('Category already exists or is invalid.');
        }
    }

    function updateCategoryOptions() {
        const categorySelector = document.getElementById('ticket-category');
        categorySelector.innerHTML = '';
        categories.forEach(cat => {
            const option = document.createElement('option');
            option.value = cat;
            option.textContent = cat;
            categorySelector.appendChild(option);
        });
    }

    // Initial call to setup categories
    updateCategoryOptions();
});